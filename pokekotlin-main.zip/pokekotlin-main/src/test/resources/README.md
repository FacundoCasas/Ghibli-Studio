# Updating testing data

The `data` directory located next to this readme is copied from https://github.com/PokeAPI/api-data.
To update it to the latest data, simply download the zip from that repo, and replace the `data` directory
here with the `data` directory from there.
