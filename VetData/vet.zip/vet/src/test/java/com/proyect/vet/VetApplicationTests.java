package com.proyect.vet;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VetApplicationTests {

	@Test
	void contextLoads() {
	}

}
